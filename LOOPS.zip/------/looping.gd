extends Node2D

func _ready() -> void:
	pass
func _process(delta: float) -> void:
	pass
func _draw() ->void:
	var r = Rect2(10, 10, 100, 30)
	draw_rect(r, Color.AQUA, false, 5)
	draw_line(Vector2(50,50), Vector2(200,200), Color.AQUAMARINE)
	draw_circle(Vector2(500, 500), 100, Color.CRIMSON)
	
	var v = get_viewport_rect()
	draw_line(Vector2(0, v.size.y), Vector2(v.size.x, 0), Color.PINK)
	for i in range(10):
		print(i)
	
	var basket = ["apple", "banana", "strawberry"]
	for i in range(basket.size()):
		print(basket[i])
	for f in basket:
		print(f)
	var num_lines = 10
	var s = get_viewport_rect().size
	var w =  s.x / num_lines
	for i in range(num_lines):
		draw_line(Vector2(i * w, 0), Vector2(i * w, s.y), Color.DARK_ORCHID)
	
	var num_h_lines = 8
	var gap = 50
	var border = 100
	for i in range(num_h_lines):
		draw_line(Vector2(border, border + gap * i), Vector2(v.size.x - border, border + gap * i), Color.LAWN_GREEN)
	var radius = 10
	var centre = Vector2(500,500)#(x,y)
	var col = Color.HOT_PINK
	#draw_circle(centre,radius,col)
	var num_cir = 10
	var t = get_viewport_rect().size
	var space = (t.x / num_cir) + 5
	for i in range(num_cir):
		draw_circle(Vector2(i * space + 15, 300),radius,col)
		radius = radius + 5
	
	
	var num_c_lines = 10
	gap = v.size.y / num_c_lines
	for i in range(num_c_lines):
		draw_line(Vector2(0, i * gap), Vector2(v.size.x, v.size.y - (i * gap)),Color.FIREBRICK)
	
	var center = get_viewport_rect().size / 2
	var theta = 0
	var radius2 = 50
	var theta_rise = .2
	var radius_rise = 2
	for i in range(100):
		var x = center.x + radius2 * cos(theta)
		var y = center.y + radius2 * sin(theta)
		draw_circle(Vector2(x, y), 2, Color.YELLOW_GREEN)
		theta += theta_rise
		radius2 += radius_rise
	
	
	pass
